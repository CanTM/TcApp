import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		ArrayList<Integer> maiorSequencia = new ArrayList<>();
		ArrayList<Integer> sequencia = new ArrayList<>();
		
		for(int i = 1; i < 1000000; i++){
			sequencia = calculaSequencia(i);
			if(sequencia.size() > maiorSequencia.size()){
				maiorSequencia = sequencia;
			}
		}

		System.out.println("O inteiro positivo abaixo de 1 milh�o produz a sequencia com mais items � " + maiorSequencia.get(0));
	}
	
	public static int calculaProximo(int n){
		int resultado = 0;
		
		if(n > 0 && n % 2 == 0){
			resultado = n / 2;
		}
		
		else if(n > 0 && n % 2 != 0){
			resultado = 3 * n + 1;
		}
		return resultado;
	}
	
	public static ArrayList<Integer> calculaSequencia(int n){
		ArrayList<Integer> sequencia = new ArrayList<>();
		sequencia.add(n);
		int proximo = n;
		while (proximo != 1 && proximo > 0) {
			proximo = calculaProximo(proximo);
			sequencia.add(proximo);
		}
		return sequencia;
	}
}
